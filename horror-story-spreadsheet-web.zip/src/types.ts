export interface Story {
  timestamp: string;
  email: string;
  title: string;
  code: string;
  episode: number;
  content: string;
  uploadLink: string;
}

export interface Novel {
  code: string;
  title: string;
  episodes: Story[];
  posterUrl: string | null;
}
