import { useState, useRef } from 'react';
import HeroSection from './components/HeroSection';
import StoryList from './components/StoryList';
import StoryReader from './components/StoryReader';
import Footer from './components/Footer';
import { useStories } from './hooks/useStories';
import type { Novel } from './types';

export default function App() {
  const { novels, loading, error, refetch } = useStories();
  const [selectedNovel, setSelectedNovel] = useState<Novel | null>(null);
  const storyListRef = useRef<HTMLDivElement>(null);

  const handleExplore = () => {
    storyListRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSelectNovel = (novel: Novel) => {
    setSelectedNovel(novel);
  };

  const handleBack = () => {
    setSelectedNovel(null);
  };

  if (selectedNovel) {
    return <StoryReader novel={selectedNovel} onBack={handleBack} />;
  }

  return (
    <div className="min-h-screen bg-black text-white selection:bg-red-900 selection:text-red-200">
      <HeroSection onExplore={handleExplore} />
      <div ref={storyListRef}>
        <StoryList
          novels={novels}
          loading={loading}
          error={error}
          onSelectNovel={handleSelectNovel}
          onRefetch={refetch}
        />
      </div>
      <Footer />
    </div>
  );
}
