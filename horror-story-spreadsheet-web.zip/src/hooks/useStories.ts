import { useState, useEffect } from 'react';
import Papa from 'papaparse';
import type { Story, Novel } from '../types';
import { getGoogleDriveImageUrl } from '../utils/driveImage';

const SHEET_URL =
  'https://docs.google.com/spreadsheets/d/e/2PACX-1vTXVkfvA5OK72TCanF2nTYnhKV0aHuIXQvIKuoQQfUrkIHQXwOeNJ3Vv7UILtanIvQz092KXWLb3zHM/pub?gid=1947422381&single=true&output=csv';

export function useStories() {
  const [novels, setNovels] = useState<Novel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStories = () => {
    setLoading(true);
    setError(null);

    Papa.parse<string[]>(SHEET_URL, {
      download: true,
      skipEmptyLines: true,
      complete(results) {
        try {
          const rows = results.data;
          if (rows.length < 2) {
            setNovels([]);
            setLoading(false);
            return;
          }

          const dataRows = rows.slice(1);
          const stories: Story[] = dataRows
            .filter((row) => row.length >= 6 && row[2]?.trim())
            .map((row) => ({
              timestamp: row[0] || '',
              email: row[1] || '',
              title: row[2] || '',
              code: row[3] || '',
              episode: parseInt(row[4]) || 1,
              content: row[5] || '',
              uploadLink: row[6] || '',
            }));

          const novelMap = new Map<string, Novel>();
          stories.forEach((story) => {
            if (!novelMap.has(story.code)) {
              novelMap.set(story.code, {
                code: story.code,
                title: story.title,
                episodes: [],
                posterUrl: null,
              });
            }
            novelMap.get(story.code)!.episodes.push(story);
          });

          novelMap.forEach((novel) => {
            novel.episodes.sort((a, b) => a.episode - b.episode);

            // Find the first episode with an upload link for the poster
            const episodeWithPoster = novel.episodes.find(
              (ep) => ep.uploadLink && ep.uploadLink.trim()
            );
            if (episodeWithPoster) {
              novel.posterUrl = getGoogleDriveImageUrl(episodeWithPoster.uploadLink);
            }
          });

          setNovels(Array.from(novelMap.values()));
        } catch {
          setError('Gagal memproses data cerita.');
        }
        setLoading(false);
      },
      error() {
        setError('Gagal mengambil data dari spreadsheet.');
        setLoading(false);
      },
    });
  };

  useEffect(() => {
    fetchStories();
  }, []);

  return { novels, loading, error, refetch: fetchStories };
}
