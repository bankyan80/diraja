/**
 * Converts a Google Drive sharing URL to a direct image URL.
 * Supports formats:
 * - https://drive.google.com/open?id=FILE_ID
 * - https://drive.google.com/file/d/FILE_ID/view
 * - https://drive.google.com/uc?id=FILE_ID
 */
export function getGoogleDriveImageUrl(driveUrl: string): string | null {
  if (!driveUrl || !driveUrl.trim()) return null;

  let fileId: string | null = null;

  // Match ?id=FILE_ID
  const idMatch = driveUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idMatch) {
    fileId = idMatch[1];
  }

  // Match /d/FILE_ID/
  if (!fileId) {
    const dMatch = driveUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
    if (dMatch) {
      fileId = dMatch[1];
    }
  }

  if (!fileId) return null;

  // Use lh3 for better image serving
  return `https://lh3.googleusercontent.com/d/${fileId}`;
}
