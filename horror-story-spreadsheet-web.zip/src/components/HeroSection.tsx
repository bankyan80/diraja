import { useState, useEffect } from 'react';

interface HeroSectionProps {
  onExplore: () => void;
}

export default function HeroSection({ onExplore }: HeroSectionProps) {
  const [flicker, setFlicker] = useState(false);
  const [showSubtitle, setShowSubtitle] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlicker(true);
      setTimeout(() => setFlicker(false), 150);
    }, 3000 + Math.random() * 4000);

    const timeout = setTimeout(() => setShowSubtitle(true), 800);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-gray-950 to-red-950/30" />
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: `radial-gradient(ellipse at 20% 50%, rgba(139, 0, 0, 0.3) 0%, transparent 50%),
                          radial-gradient(ellipse at 80% 20%, rgba(100, 0, 0, 0.2) 0%, transparent 50%),
                          radial-gradient(ellipse at 50% 80%, rgba(80, 0, 0, 0.4) 0%, transparent 50%)`
      }} />

      {/* Fog / mist animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -left-1/4 top-1/4 w-[150%] h-64 bg-gradient-to-r from-transparent via-gray-800/10 to-transparent animate-pulse rounded-full blur-3xl" />
        <div className="absolute -right-1/4 top-2/3 w-[150%] h-48 bg-gradient-to-r from-transparent via-red-900/5 to-transparent rounded-full blur-3xl" style={{ animation: 'pulse 5s ease-in-out infinite' }} />
      </div>

      {/* Floating particles */}
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-red-500/30 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animation: `float ${5 + Math.random() * 10}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
          }}
        />
      ))}

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Skull / Horror icon */}
        <div className="mb-8 text-7xl md:text-8xl animate-bounce" style={{ animationDuration: '3s' }}>
          💀
        </div>

        <h1
          className={`text-5xl md:text-7xl lg:text-8xl font-black tracking-wider transition-opacity duration-150 ${
            flicker ? 'opacity-20' : 'opacity-100'
          }`}
          style={{
            fontFamily: "'Creepster', cursive, system-ui",
            color: '#dc2626',
            textShadow: '0 0 20px rgba(220, 38, 38, 0.5), 0 0 40px rgba(220, 38, 38, 0.3), 0 0 80px rgba(220, 38, 38, 0.1), 0 4px 8px rgba(0,0,0,0.8)',
          }}
        >
          CERITA HOROR
        </h1>

        <div
          className={`mt-4 h-0.5 mx-auto bg-gradient-to-r from-transparent via-red-600 to-transparent transition-all duration-1000 ${
            showSubtitle ? 'w-64 md:w-96 opacity-100' : 'w-0 opacity-0'
          }`}
        />

        <p
          className={`mt-6 text-lg md:text-xl text-gray-400 tracking-widest uppercase transition-all duration-1000 delay-300 ${
            showSubtitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          Kisah Malam yang Mencekam
        </p>

        <p
          className={`mt-4 text-sm md:text-base text-gray-500 max-w-xl mx-auto leading-relaxed transition-all duration-1000 delay-500 ${
            showSubtitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          Kumpulan cerita seram yang akan membuatmu tidak bisa tidur di malam hari.
          Berani membaca sampai habis?
        </p>

        <button
          onClick={onExplore}
          className={`mt-10 px-8 py-4 bg-red-700/20 border border-red-700/50 text-red-400 rounded-lg
            hover:bg-red-700/40 hover:border-red-500 hover:text-red-300 hover:shadow-lg hover:shadow-red-900/30
            transition-all duration-500 tracking-widest uppercase text-sm font-semibold
            ${showSubtitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}
          `}
          style={{ transitionDelay: '700ms' }}
        >
          🕯️ Mulai Membaca 🕯️
        </button>

        {/* Scroll indicator */}
        <div className={`mt-16 transition-all duration-1000 delay-1000 ${showSubtitle ? 'opacity-60' : 'opacity-0'}`}>
          <div className="w-6 h-10 border-2 border-gray-600 rounded-full mx-auto flex justify-center">
            <div className="w-1.5 h-3 bg-gray-500 rounded-full mt-2 animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}
