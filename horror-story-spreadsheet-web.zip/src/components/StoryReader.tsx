import { useState, useEffect } from 'react';
import type { Novel } from '../types';
import { getGoogleDriveImageUrl } from '../utils/driveImage';

interface StoryReaderProps {
  novel: Novel;
  onBack: () => void;
}

export default function StoryReader({ novel, onBack }: StoryReaderProps) {
  const [currentEpisode, setCurrentEpisode] = useState(0);
  const [fadeIn, setFadeIn] = useState(false);
  const [showContent, setShowContent] = useState(false);
  const [posterLoaded, setPosterLoaded] = useState(false);
  const [posterError, setPosterError] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setFadeIn(false);
    setShowContent(false);
    setPosterLoaded(false);
    setPosterError(false);
    const t1 = setTimeout(() => setFadeIn(true), 100);
    const t2 = setTimeout(() => setShowContent(true), 400);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [currentEpisode]);

  const episode = novel.episodes[currentEpisode];
  const paragraphs = episode.content.split('\n').filter((p) => p.trim());

  // Get the poster for the current episode, fallback to novel poster
  const currentEpisodePoster = episode.uploadLink
    ? getGoogleDriveImageUrl(episode.uploadLink)
    : null;
  const displayPoster = currentEpisodePoster || novel.posterUrl;
  const showPoster = displayPoster && !posterError;

  return (
    <div className="relative min-h-screen bg-black">
      {/* Ambient background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-red-950/10 via-black to-black" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-red-900/5 rounded-full blur-3xl" />
      </div>

      {/* Top navigation */}
      <nav className="sticky top-0 z-50 bg-black/90 backdrop-blur-md border-b border-gray-900">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-red-400 transition-colors duration-300"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="text-sm">Kembali</span>
          </button>

          <div className="text-center">
            <h2 className="text-sm font-bold text-red-500 truncate max-w-[200px] md:max-w-none">
              {novel.title}
            </h2>
            <p className="text-xs text-gray-600">
              Episode {episode.episode} / {novel.episodes.length}
            </p>
          </div>

          <div className="w-20" />
        </div>
      </nav>

      {/* Poster Hero Banner */}
      {showPoster && (
        <div
          className={`relative w-full h-72 md:h-96 overflow-hidden transition-opacity duration-1000 ${
            fadeIn ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {/* Loading skeleton */}
          {!posterLoaded && (
            <div className="absolute inset-0 bg-gray-900 animate-pulse flex items-center justify-center z-10">
              <div className="flex flex-col items-center gap-3">
                <div className="text-5xl animate-bounce">🕯️</div>
                <p className="text-gray-600 text-sm animate-pulse">Memuat poster...</p>
              </div>
            </div>
          )}

          {/* Poster image */}
          <img
            src={displayPoster!}
            alt={`Poster ${episode.title}`}
            className={`w-full h-full object-cover transition-all duration-1000 ${
              posterLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            }`}
            onLoad={() => setPosterLoaded(true)}
            onError={() => setPosterError(true)}
            referrerPolicy="no-referrer"
            crossOrigin="anonymous"
          />

          {/* Multi-layer overlay for horror atmosphere */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-red-900/10" />

          {/* Vignette effect */}
          <div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.7) 100%)',
            }}
          />

          {/* Title overlay on poster */}
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 z-10">
            <div className="max-w-3xl mx-auto">
              <span className="inline-block px-3 py-1 bg-red-900/50 border border-red-800/50 rounded-full text-xs text-red-300 mb-3 backdrop-blur-sm">
                📖 Episode {episode.episode}
              </span>
              <h1
                className="text-3xl md:text-5xl font-black text-white leading-tight"
                style={{
                  textShadow:
                    '0 0 30px rgba(220, 38, 38, 0.4), 0 2px 10px rgba(0,0,0,0.8)',
                }}
              >
                {episode.title}
              </h1>
              <p className="mt-2 text-sm text-gray-400">
                {episode.timestamp}
              </p>
            </div>
          </div>

          {/* Decorative corner blood drips */}
          <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-red-900/20 to-transparent" />
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-red-900/20 to-transparent" />
        </div>
      )}

      {/* Content */}
      <article
        className={`relative z-10 max-w-3xl mx-auto px-6 md:px-8 py-12 transition-all duration-700 ${
          fadeIn ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Episode header - only show if no poster */}
        {!showPoster && (
          <header className="text-center mb-12">
            <span className="text-4xl block mb-4">🕯️</span>
            <h1
              className="text-2xl md:text-4xl font-black text-red-500 tracking-wider"
              style={{
                textShadow: '0 0 20px rgba(220, 38, 38, 0.3)',
              }}
            >
              {episode.title}
            </h1>
            <div className="mt-3 h-px w-24 mx-auto bg-gradient-to-r from-transparent via-red-700 to-transparent" />
            <p className="mt-3 text-sm text-gray-600">
              Episode {episode.episode} • {episode.timestamp}
            </p>
          </header>
        )}

        {/* Poster-style header separator when poster is shown */}
        {showPoster && (
          <div className="mb-10 flex items-center justify-center gap-4">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent to-red-900/50" />
            <span className="text-2xl">☠️</span>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent to-red-900/50" />
          </div>
        )}

        {/* Story content */}
        <div
          className={`space-y-6 transition-all duration-1000 delay-200 ${
            showContent ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {paragraphs.map((paragraph, index) => (
            <p
              key={index}
              className="text-gray-300 leading-relaxed md:leading-loose text-base md:text-lg first-letter:text-3xl first-letter:font-bold first-letter:text-red-500 first-letter:float-left first-letter:mr-2 first-letter:mt-1"
              style={{
                textShadow: '0 1px 2px rgba(0,0,0,0.5)',
              }}
            >
              {paragraph}
            </p>
          ))}
        </div>

        {/* Decorative divider */}
        <div className="mt-16 flex items-center justify-center gap-4 text-gray-700">
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-gray-700" />
          <span>☠️</span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-gray-700" />
        </div>

        {/* Episode navigation */}
        <div className="mt-8 flex items-center justify-between gap-4">
          <button
            onClick={() => setCurrentEpisode((prev) => prev - 1)}
            disabled={currentEpisode === 0}
            className="flex items-center gap-2 px-5 py-3 bg-gray-900/50 border border-gray-800 rounded-lg
              text-gray-400 hover:border-red-800 hover:text-red-400 transition-all duration-300
              disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:border-gray-800 disabled:hover:text-gray-400"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="text-sm">Sebelumnya</span>
          </button>

          {/* Episode selector */}
          <div className="flex items-center gap-2 flex-wrap justify-center">
            {novel.episodes.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentEpisode(i)}
                className={`w-8 h-8 rounded-full text-xs font-bold transition-all duration-300 ${
                  i === currentEpisode
                    ? 'bg-red-700 text-white shadow-lg shadow-red-900/50'
                    : 'bg-gray-900 text-gray-500 hover:bg-gray-800 hover:text-gray-300'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentEpisode((prev) => prev + 1)}
            disabled={currentEpisode >= novel.episodes.length - 1}
            className="flex items-center gap-2 px-5 py-3 bg-gray-900/50 border border-gray-800 rounded-lg
              text-gray-400 hover:border-red-800 hover:text-red-400 transition-all duration-300
              disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:border-gray-800 disabled:hover:text-gray-400"
          >
            <span className="text-sm">Selanjutnya</span>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </article>

      {/* Bottom atmosphere */}
      <div className="h-32 bg-gradient-to-t from-black to-transparent" />
    </div>
  );
}
