import type { Novel } from '../types';
import StoryCard from './StoryCard';

interface StoryListProps {
  novels: Novel[];
  loading: boolean;
  error: string | null;
  onSelectNovel: (novel: Novel) => void;
  onRefetch: () => void;
}

export default function StoryList({ novels, loading, error, onSelectNovel, onRefetch }: StoryListProps) {
  // Check if any novel has a poster
  const hasPosterNovels = novels.some((n) => n.posterUrl);

  return (
    <section id="stories" className="relative min-h-screen py-20 px-4">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-red-950/30 via-gray-950 to-black" />

      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-5xl mb-4 block">📖</span>
          <h2
            className="text-3xl md:text-5xl font-black text-red-500 tracking-wider"
            style={{
              textShadow: '0 0 20px rgba(220, 38, 38, 0.3), 0 0 40px rgba(220, 38, 38, 0.1)',
            }}
          >
            Daftar Cerita
          </h2>
          <div className="mt-3 h-px w-32 mx-auto bg-gradient-to-r from-transparent via-red-600 to-transparent" />
          <p className="mt-4 text-gray-500 text-sm tracking-wider uppercase">
            Pilih cerita yang berani kamu baca
          </p>
          <button
            onClick={onRefetch}
            className="mt-4 px-4 py-2 text-xs text-gray-500 border border-gray-800 rounded-lg hover:border-red-800 hover:text-red-400 transition-all duration-300"
          >
            🔄 Refresh Cerita
          </button>
        </div>

        {/* Loading state */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-gray-800 rounded-full" />
              <div className="absolute top-0 left-0 w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
            </div>
            <p className="mt-6 text-gray-500 animate-pulse tracking-wider">Memuat cerita dari kegelapan...</p>
          </div>
        )}

        {/* Error state */}
        {error && (
          <div className="text-center py-20">
            <span className="text-5xl block mb-4">⚠️</span>
            <p className="text-red-400 mb-4">{error}</p>
            <button
              onClick={onRefetch}
              className="px-6 py-2 bg-red-900/30 border border-red-800 text-red-400 rounded-lg hover:bg-red-900/50 transition-all"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && novels.length === 0 && (
          <div className="text-center py-20">
            <span className="text-5xl block mb-4">🌑</span>
            <p className="text-gray-500">Belum ada cerita yang tersedia...</p>
            <p className="text-gray-600 text-sm mt-2">Kegelapan masih menunggu ceritanya ditulis.</p>
          </div>
        )}

        {/* Story cards grid - responsive based on poster availability */}
        {!loading && !error && novels.length > 0 && (
          <div
            className={
              hasPosterNovels
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8'
                : 'grid grid-cols-1 md:grid-cols-2 gap-6'
            }
          >
            {novels.map((novel, index) => (
              <StoryCard
                key={novel.code}
                novel={novel}
                index={index}
                onClick={() => onSelectNovel(novel)}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
