import { useState } from 'react';
import type { Novel } from '../types';

interface StoryCardProps {
  novel: Novel;
  index: number;
  onClick: () => void;
}

const horrorIcons = ['👻', '🦇', '🕷️', '⚰️', '🔮', '🌑', '🩸', '😱', '💀', '🕯️'];

export default function StoryCard({ novel, index, onClick }: StoryCardProps) {
  const icon = horrorIcons[index % horrorIcons.length];
  const [imgError, setImgError] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);

  const hasPoster = novel.posterUrl && !imgError;

  return (
    <button
      onClick={onClick}
      className="group relative w-full text-left bg-gray-950/80 border border-gray-800/50 rounded-xl overflow-hidden
        hover:border-red-800/60 hover:shadow-2xl hover:shadow-red-900/30
        transition-all duration-500 transform hover:-translate-y-2"
    >
      {/* Top gradient accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-900 via-red-600 to-red-900 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-20" />

      {/* Glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-900/0 to-red-900/0 group-hover:from-red-900/5 group-hover:to-red-900/10 transition-all duration-500 z-10" />

      {/* Poster Image Section */}
      {hasPoster && (
        <div className="relative w-full h-56 md:h-64 overflow-hidden">
          {/* Loading skeleton */}
          {!imgLoaded && (
            <div className="absolute inset-0 bg-gray-900 animate-pulse flex items-center justify-center">
              <div className="text-4xl animate-bounce">💀</div>
            </div>
          )}

          {/* Poster image */}
          <img
            src={novel.posterUrl!}
            alt={`Poster ${novel.title}`}
            className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:brightness-75 ${
              imgLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImgLoaded(true)}
            onError={() => setImgError(true)}
            referrerPolicy="no-referrer"
            crossOrigin="anonymous"
          />

          {/* Dark overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/60 to-transparent" />

          {/* Red horror tint on hover */}
          <div className="absolute inset-0 bg-red-900/0 group-hover:bg-red-900/20 transition-all duration-500" />

          {/* Episode badge on image */}
          <div className="absolute top-3 right-3 z-10">
            <span className="px-3 py-1.5 bg-black/70 backdrop-blur-sm border border-red-800/50 rounded-full text-xs text-red-400 font-bold shadow-lg shadow-red-900/30">
              🩸 {novel.episodes.length} Episode
            </span>
          </div>

          {/* Novel code badge */}
          <div className="absolute top-3 left-3 z-10">
            <span className="px-3 py-1.5 bg-black/70 backdrop-blur-sm border border-gray-700/50 rounded-full text-xs text-gray-400 font-mono">
              {novel.code}
            </span>
          </div>

          {/* Title overlay on image */}
          <div className="absolute bottom-0 left-0 right-0 p-5 z-10">
            <h3
              className="text-xl md:text-2xl font-black text-white group-hover:text-red-400 transition-colors duration-300 drop-shadow-lg"
              style={{
                textShadow: '0 2px 8px rgba(0,0,0,0.8)',
              }}
            >
              {icon} {novel.title}
            </h3>
          </div>
        </div>
      )}

      {/* Content section */}
      <div className="relative p-5 z-10">
        {/* Show title & icon only if no poster */}
        {!hasPoster && (
          <div className="flex items-start gap-4 mb-3">
            <div className="text-4xl transform group-hover:scale-110 group-hover:rotate-12 transition-transform duration-300">
              {icon}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-gray-200 group-hover:text-red-400 transition-colors duration-300 truncate">
                {novel.title}
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                Kode: {novel.code}
              </p>
              <div className="mt-2 flex items-center gap-3">
                <span className="px-2.5 py-1 bg-red-900/30 border border-red-800/30 rounded-md text-xs text-red-400">
                  {novel.episodes.length} Episode
                </span>
                <span className="text-xs text-gray-600">
                  {novel.episodes[0]?.timestamp}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Preview text */}
        <p className="text-sm text-gray-500 line-clamp-2 leading-relaxed">
          {novel.episodes[0]?.content.substring(0, 150)}...
        </p>

        {/* Timestamp for poster cards */}
        {hasPoster && (
          <div className="mt-2 flex items-center gap-2 text-xs text-gray-600">
            <span>🕐</span>
            <span>{novel.episodes[0]?.timestamp}</span>
          </div>
        )}

        {/* Read indicator */}
        <div className="mt-4 flex items-center justify-end gap-2 text-gray-600 group-hover:text-red-500 transition-colors duration-300">
          <span className="text-xs uppercase tracking-wider font-semibold">Baca Cerita</span>
          <svg className="w-4 h-4 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </div>
      </div>
    </button>
  );
}
