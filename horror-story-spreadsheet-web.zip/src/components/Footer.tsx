export default function Footer() {
  return (
    <footer className="relative bg-black border-t border-gray-900/50">
      <div className="max-w-5xl mx-auto px-4 py-12 text-center">
        <span className="text-3xl block mb-4">🦇</span>
        <h3
          className="text-xl font-black text-red-600 tracking-widest"
          style={{
            textShadow: '0 0 10px rgba(220, 38, 38, 0.3)',
          }}
        >
          CERITA HOROR
        </h3>
        <p className="mt-2 text-gray-600 text-sm">
          Kisah Malam yang Mencekam
        </p>
        <div className="mt-4 h-px w-24 mx-auto bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
        <p className="mt-4 text-gray-700 text-xs">
          Data cerita diambil dari Google Spreadsheet secara real-time.
        </p>
        <p className="mt-2 text-gray-800 text-xs">
          © 2026 • Dibuat dengan 🖤 dan ketakutan
        </p>
      </div>
    </footer>
  );
}
